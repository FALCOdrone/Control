%% Initialization file for MRC example

% The plant considered in this example represents a first order model of 
% the roll rate dynamics for a conventional aircraft.
% A feedback-feedforward Model Reference Controller is first implemented
% and then an extended version with error feedback is considered
% Familiarize yourself with the effect of chaning the estimated parameters
% in the control laws.
% Author: Davide Invernizzi
% Version: 17/09/2021

%% Plant Model

L_p = -.8; % true value of roll rate damping   
L_delta = 1.6; % true value of roll moment control derivative 
sat=100; % set to a large number (ex: 1000) to disable the saturation

%% Reference model

a_r = -2;
b_r = 2;

%% MRC 

k_p_bar = (a_r-L_p)/L_delta;
k_f_bar = b_r/L_delta;

K_bar=[k_p_bar k_f_bar]; % ideal gains

% Estimated values 

L_p_hat = L_p;
L_delta_hat = L_delta;

L_p_hat = L_p*(1+.2*rand(1));
L_delta_hat = L_delta*(1+.2*rand(1)); % comment to use ideal values

k_p = (a_r-L_p_hat)/L_delta_hat;
k_f = b_r/L_delta_hat;

K = [k_p k_f];

%% MRC with error feedback

k_e = 2;

K_ext = [k_e k_p k_f];

